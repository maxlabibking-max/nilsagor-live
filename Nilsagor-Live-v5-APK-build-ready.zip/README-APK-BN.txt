NILSAGOR LIVE - APK BUILD PROJECT

ফোন থেকেই APK বানানোর জন্য:
1. এই ZIP GitHub repository-তে upload করুন।
2. Repository-এর Actions tab খুলুন।
3. “Build Nilsagor Live APK” workflow নির্বাচন করুন।
4. Run workflow চাপুন।
5. কাজ শেষ হলে Nilsagor-Live-debug-apk artifact থেকে app-debug.apk নিন।

এটি debug APK। Play Store release-এর জন্য আলাদা signed release build প্রয়োজন।

App ID: com.nilsagor.live
Version: 5.0
Web app files assets/ এর ভিতরে রাখা হয়েছে।
