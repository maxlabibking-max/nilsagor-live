NILSAGOR LIVE

Firebase:
1. Firebase Authentication-এ Email/Password এবং Google enable করুন।
2. Firestore Database তৈরি করুন।
3. firestore.rules Firebase Console-এর Rules-এ বসান।
4. Owner email: maxlabibking@gmail.com

Netlify:
এই folder-এর সব file Netlify Drop-এ upload করুন।

IMPORTANT:
Normal YouTube/Facebook page URL সবসময় iframe-এ চলে না। Official embeddable URL অথবা browser-compatible direct stream ব্যবহার করতে হবে।
Fake channel/stream রাখা হয়নি।


CHANNEL CATALOG:
channel-catalog.json includes a large real-name Bangladesh TV/radio catalog and international TV catalog. Entries are disabled until a real authorized browser-compatible source is configured, so the app never pretends an unavailable stream is live.

Bangladesh does not have 200 separate on-air TV channels; the current public list reports 59 permitted and 42 currently on air. The app therefore uses the real catalog rather than inventing 200 channels.


Country update:
- TV এবং Radio-তে Country mode আলাদা selector ব্যবহার করে দেশ নির্বাচন করা যায়।
- Search box channel/station ও country name দিয়ে filter করে।
- Catalog entry-তে source না থাকলে সেটি শুধু তালিকায় থাকবে; fake playback হবে না।
- বাস্তব official/public/licensed stream বা supported embed URL Admin Panel থেকে যোগ করতে হবে।

Public-source note: আন্তর্জাতিক radio catalog-গুলোও country-based public stream data ব্যবহার করে; stream availability broadcaster/region/browser-এর ওপর নির্ভর করতে পারে।
