import {firebaseConfig,ADMIN_EMAIL} from "./firebase-config.js";
import{initializeApp}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import{getAuth,GoogleAuthProvider,signInWithPopup,signInWithEmailAndPassword,createUserWithEmailAndPassword,onAuthStateChanged,signOut}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import{getFirestore,collection,addDoc,getDocs,deleteDoc,doc,serverTimestamp}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app);
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
let currentUser=null,currentCat={tv:"Bangladesh",radio:"Bangladesh"},currentCountry={tv:"All",radio:"All"},channels=[];

function showApp(){document.querySelector("#authScreen").classList.add("hidden");document.querySelector("#app").classList.remove("hidden")}
function showLogin(){document.querySelector("#app").classList.add("hidden");document.querySelector("#authScreen").classList.remove("hidden")}
onAuthStateChanged(auth,u=>{currentUser=u;if(u){showApp();checkAdmin()}else showLogin()});

$("#googleBtn").onclick=async()=>{try{await signInWithPopup(auth,new GoogleAuthProvider())}catch(e){$("#authMsg").textContent=e.message}};
$("#loginBtn").onclick=async()=>{try{await signInWithEmailAndPassword(auth,$("#email").value,$("#password").value)}catch(e){$("#authMsg").textContent=e.message}};
$("#signupBtn").onclick=async()=>{try{await createUserWithEmailAndPassword(auth,$("#email").value,$("#password").value)}catch(e){$("#authMsg").textContent=e.message}};
$("#logoutBtn").onclick=()=>signOut(auth);

$$("[data-view]").forEach(b=>b.onclick=()=>navigate(b.dataset.view));
function navigate(v){$$(".view").forEach(x=>x.classList.toggle("active",x.id===v));$$(".tabs button").forEach(x=>x.classList.toggle("active",x.dataset.view===v));$("#drawer").classList.remove("open");$("#shade").classList.add("hidden");if(v==="tv")render("tv");if(v==="radio")render("radio");if(v==="sports")render("sports");if(v==="admin")renderAdmin()}
$("#menuBtn").onclick=()=>{$("#drawer").classList.add("open");$("#shade").classList.remove("hidden")};
$("#closeMenu").onclick=$("#shade").onclick=()=>{$("#drawer").classList.remove("open");$("#shade").classList.add("hidden")};

async function loadChannels(){
 channels=[];
 try{const local=await fetch("./channel-catalog.json").then(r=>r.json());local.forEach((x,i)=>channels.push({id:"catalog-"+i,...x}))}catch(e){console.error(e)}
 try{const snap=await getDocs(collection(db,"channels"));snap.forEach(d=>channels.push({id:d.id,...d.data()}))}catch(e){console.error(e)}
 render("tv");render("radio");render("sports");renderAdmin()
}
function esc(x=""){return String(x).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function countryButtons(type){
 const select=$(type==="tv"?"#tvCountrySelect":"#radioCountrySelect");
 const list=[...new Set(channels.filter(x=>x.type===type&&x.category==="Country"&&(x.isCatalog||x.enabled!==false)).map(x=>x.country).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
 select.innerHTML='<option value="All">🌍 All Countries</option>'+list.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join("");
 select.value=currentCountry[type]||"All";
 select.classList.toggle("hidden",currentCat[type]!=="Country");
 select.onchange=()=>{currentCountry[type]=select.value;render(type)};
 const oldBox=$(type==="tv"?"#tvCountries":"#radioCountries");
 oldBox.classList.add("hidden");
}
function render(type){
 if(type==="sports"){draw($("#sportsGrid"),channels.filter(x=>x.type==="sports"&&(x.isCatalog||x.enabled!==false)),"");return}
 countryButtons(type);
 const search=$(type==="tv"?"#tvSearch":"#radioSearch").value.trim().toLowerCase();
 let list=channels.filter(x=>x.type===type&&x.category===currentCat[type]&&(x.isCatalog||x.enabled!==false));
 if(currentCat[type]==="Country"&&currentCountry[type]!=="All")list=list.filter(x=>x.country===currentCountry[type]);
 if(search)list=list.filter(x=>`${x.name} ${x.country||""} ${x.description||""}`.toLowerCase().includes(search));
 draw($("#"+type+"Grid"),list,search);
}
function draw(box,list){
 box.innerHTML=list.length?list.map(x=>`<article class="channel">${x.logo?`<img src="${esc(x.logo)}" alt="">`:`<div class="logo" style="width:55px;height:55px;font-size:15px">NL</div>`}<h3>${esc(x.name)}</h3><div class="muted">${esc(x.country||"Bangladesh")}</div>${(x.streamUrl||x.embedUrl)&&x.enabled!==false?`<button class="play" data-id="${esc(x.id)}">▶ Play</button>`:`<div class="muted" style="margin-top:10px">Source not configured</div>`}</article>`).join(""):`<div class="card"><b>No channels found.</b><p class="muted">Country, name or source দিয়ে search/filter পরিবর্তন করুন।</p></div>`;
 box.querySelectorAll("[data-id]").forEach(b=>b.onclick=()=>play(channels.find(x=>x.id===b.dataset.id)));
}
$$(".switch button").forEach(b=>b.onclick=()=>{const t=b.dataset.type;currentCat[t]=b.dataset.cat;currentCountry[t]="All";$$(`.switch button[data-type="${t}"]`).forEach(x=>x.classList.toggle("active",x===b));render(t)});

function play(x){if(!x)return;$("#playerContent").innerHTML="";const u=x.embedUrl||x.streamUrl||"";if(!u){$("#playerContent").innerHTML="<p>Stream unavailable.</p>";$("#player").classList.remove("hidden");return}if(x.type==="radio"){const a=document.createElement("audio");a.controls=true;a.autoplay=true;a.src=x.streamUrl;$("#playerContent").appendChild(a)}else if(x.embedUrl){const f=document.createElement("iframe");f.src=x.embedUrl;f.allow="autoplay; encrypted-media; picture-in-picture";f.allowFullscreen=true;$("#playerContent").appendChild(f)}else{const v=document.createElement("video");v.controls=true;v.autoplay=true;v.playsInline=true;v.src=x.streamUrl;$("#playerContent").appendChild(v)}$("#player").classList.remove("hidden")}
$("#closePlayer").onclick=()=>{$("#player").classList.add("hidden");$("#playerContent").innerHTML=""};

function checkAdmin(){const ok=currentUser?.email?.toLowerCase()===ADMIN_EMAIL.toLowerCase();$("#adminLocked").classList.toggle("hidden",ok);$("#adminArea").classList.toggle("hidden",!ok);if(ok)loadChannels()}
$("#add").onclick=async()=>{if(currentUser?.email?.toLowerCase()!==ADMIN_EMAIL.toLowerCase())return alert("Admin access denied");const data={type:$("#type").value,category:$("#category").value,name:$("#name").value.trim(),country:$("#country").value.trim(),logo:$("#logo").value.trim(),streamUrl:$("#stream").value.trim(),embedUrl:$("#embedUrl").value.trim(),enabled:true,createdAt:serverTimestamp(),updatedAt:serverTimestamp()};if(!data.name||(!data.streamUrl&&!data.embedUrl))return alert("Channel name এবং Stream/Embed URL দিন");await addDoc(collection(db,"channels"),data);["#name","#country","#logo","#stream","#embedUrl"].forEach(x=>$(x).value="");await loadChannels()};
async function renderAdmin(){if(currentUser?.email?.toLowerCase()!==ADMIN_EMAIL.toLowerCase())return;const box=$("#adminList");const own=channels.filter(x=>!x.isCatalog);box.innerHTML=own.length?own.map(x=>`<div class="admin-item"><b>${esc(x.name)}</b><div class="muted">${esc(x.type)} • ${esc(x.category)} • ${esc(x.country||"")}</div><button data-del="${esc(x.id)}">Delete</button></div>`).join(""):"<div class=\"muted\">No Firestore channels added yet.</div>";$$("[data-del]").forEach(b=>b.onclick=async()=>{if(confirm("Delete this channel?")){await deleteDoc(doc(db,"channels",b.dataset.del));await loadChannels()}})}
let micStream=null,micTimer=null;
$("#micBtn").onclick=async()=>{try{if(micStream){micStream.getTracks().forEach(t=>t.stop());micStream=null;$("#micBtn").textContent="Start Microphone";$("#micStatus").textContent="Microphone idle";return}micStream=await navigator.mediaDevices.getUserMedia({audio:true});$("#micBtn").textContent="Stop Microphone";$("#micStatus").textContent="Microphone active";const c=new AudioContext(),s=c.createMediaStreamSource(micStream),a=c.createAnalyser();s.connect(a);a.fftSize=64;const d=new Uint8Array(a.frequencyBinCount);micTimer=setInterval(()=>{a.getByteFrequencyData(d);$("#meter").style.width=Math.min(100,d.reduce((p,n)=>p+n,0)/d.length*2)+"%"},100)}catch(e){$("#micStatus").textContent="Microphone permission failed: "+e.message}};
let camStream=null;
$("#cameraBtn").onclick=async()=>{try{camStream=await navigator.mediaDevices.getUserMedia({video:true,audio:true});$("#camera").srcObject=camStream}catch(e){alert("Camera permission failed: "+e.message)}};
$("#stopCamera").onclick=()=>{if(camStream)camStream.getTracks().forEach(t=>t.stop());$("#camera").srcObject=null};
$("#embedBtn").onclick=()=>{const u=$("#embed").value.trim();if(!u)return;$("#embedBox").classList.remove("hidden");$("#embedBox").innerHTML=`<iframe src="${esc(u)}" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`};
$("#tvSearch").oninput=()=>render("tv");
$("#radioSearch").oninput=()=>render("radio");
loadChannels();if("serviceWorker"in navigator)navigator.serviceWorker.register("./sw.js");
